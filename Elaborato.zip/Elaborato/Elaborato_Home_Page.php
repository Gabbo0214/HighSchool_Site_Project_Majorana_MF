<!--Inizializzo la sessione e cancello eventuali errori impostati nelle variabili di sessione.-->
<?php
session_start();
if (isset($_SESSION['errset'])){
unset($_SESSION['errset']);}
?>
<!DOCTYPE html>
<html>
<head>
<!--Titolo della pagina-->
<title>Home Page-Vaccinazione anti-covid</title>
<!--Codice css per la personalizzazione-->
<style>
.button {
  border: none;
  color: white;
  padding: 12px 28px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.container {
  position: relative;
}

.button1 {
  position:fixed;
  top: 1%;
  right: 1%;
  background-color: white; 
  color: black; 
  border: 2px solid #FF0000;
}

.button1:hover {
  background-color: #FF0000;
  color: white;
}

.button2 {
  position:static;
  background-color: white; 
  color: black; 
  border: 2px solid #000080;
}

.button2:hover {
  background-color: #000080;
  color: white;
}

.button3 {
  position:static;
  background-color: white; 
  color: black; 
  border: 2px solid #32CD32;
}

.button3:hover {
  background-color: #32CD32;
  color: white;
}

.h1 {
  font-family: "Optima", Optima, sans-serif;
  font-variant: small-caps;
}
.h3 {
  font-family: "Optima", Optima, sans-serif;
  font-variant: small-caps;
}

.immagine {
	position:fixed;
    bottom:50%;
	left:40%;
}

.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: red;
   color: white;
   text-align: center;
}

</style>
</head>
<body class="container">
<!--Bottoni e logo della pagina.-->
<img src="primula.jpg" alt="Logo Pagina" width="300" height="120">
<h1 class=h1>Benvenuto</h1>
<h3 class=h3>Seleziona un servizio.</h3>
<form action="Elaborato_Pagina_Di_Accesso.php" class="inline">
<button class="button button1")>Log Out</button>
</form>


<form action="Elaborato_Ricerca_Pazienti.php" class="inline">
<button class="button button2")>Ricerca Dati</button>
</form>

<?php 
//Se ho effettuato il login come sanitario, otterrò i permessi per poter utilizzare il servizio di registrazione pazienti
if($_SESSION["permission"]=="true"){ ?>
<form action="Elaborato_Registrazione_Pazienti.php" class="inline">
<button class="button button3")>Registra un paziente</button>
</form>
<br><br>
<?php 
} 
?>
<img src="majorana.png" class=immagine alt="Logo Scuola" width="500" height="200">
<!--footer della pagina contenente informazioni.-->
<div class="footer">
  <p>Copyright &#169; appartenente a "Gabriele Melucci s.r.l." 2020-2021<br>
  per maggiori informazioni, contattare su<br></p>
  <address>gabriele.melucci@gmail.com</address><br>
  <sup>nessuna nota legale al momento disponibile</sup>
</div>

</body>
</html>