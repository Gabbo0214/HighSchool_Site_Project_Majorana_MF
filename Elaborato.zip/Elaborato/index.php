<?php
	$url = 'Elaborato/Elaborato_Pagina_Di_Accesso.php';
	header( "Location: $url" );
?>