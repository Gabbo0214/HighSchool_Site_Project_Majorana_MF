<!--Inizializzo la sessione e mi connetto al database.-->
<?php
session_start();
$servername = "localhost";
$username = "elaboratovacciniassurdi";
$password = "Gogeta12";
$dbname = "my_elaboratovacciniassurdi";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error){
  die("Connessione al database fallita: ".$conn->connect_error." ");
}
//imposto le variabili di sessione riguardo possibili errori e passo i dati inseriti nel form tramite metodo post
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$_SESSION["loginerr"]="";
    $_SESSION["rolerr"]="";
    $_SESSION["userr"]="";
    $_SESSION["passerr"]="";
	$_SESSION["permission"]="";
	$username=$_POST["username"];
	$password=$_POST["password"];
	$ruolo=$_POST["ruolo"];
	$er=0;
	
//assegno la chiave dell'utente in base al ruolo
	if ($ruolo=="sanitario_user"){
	$chiave="id";
	}else{
		if($ruolo=="ente_locale_user"){
		$chiave="Codice_Ente";	
		}else{
		   if($ruolo=="Capo_Dipartimento_Regionale_user"){
		   $chiave="id";
		   }
		}
	}
//effettuo i controlli di username e password per il login
	$sql = "SELECT username FROM $ruolo";
    $result = $conn->query($sql);
    if ($result->num_rows > 0){
       while($row = $result->fetch_assoc()) {
           if($username==$row["username"]){
			   //controllo la chiave a cui appartiene l'username per riconoscere univocamente l'account
			   $sql = "SELECT $chiave FROM $ruolo where username='$username'";
		       $result = $conn->query($sql);
		       if ($result->num_rows > 0){
		        while($row = $result->fetch_assoc()) {
				   if($chiave=="id"){
			       $value1=$row["id"];}else{
				   $value1=$row["Codice_Ente"];}}
		       }
			   $un=1;
			   break;
         	}else{
//se il nome utente è errato, l'errore viene segnato
            $un=0;}
       }
    } else {
//se non sono presenti username nel database, viene segnalato un errore
    echo "Errore nel database utenti.";
	$er=1;
    }

    $sql = "SELECT password FROM $ruolo";
    $result = $conn->query($sql);
    if ($result->num_rows > 0){
       while($row = $result->fetch_assoc()) {
           if($password==$row["password"]){
			   //controllo la chiave a cui appartiene la password per riconoscere univocamente l'account
			   $sql = "SELECT $chiave FROM $ruolo where password='$password'";
		       $result = $conn->query($sql);
		       if ($result->num_rows > 0){
		       while($row = $result->fetch_assoc()) {
				   if($chiave=="id"){
			       $value2=$row["id"];}else{
				   $value2=$row["Codice_Ente"];}
		       }}
			   $pw=1;
			   break;
         	}else{
//se la password è errata, l'errore viene segnato				
			$pw=0;}
       }
    } else {
//se non sono presenti password nel database, viene segnalato un errore
    echo "Errore nel database utenti.";
	$er=1;
    }
//se non ci sono stati errori precedenti ed il nome utente e password coincidono allo stesso id, il login viene effettuato
	if($er!=1 & $value1==$value2 & $un==1 & $pw==1){
	if($ruolo=="sanitario_user"){
    $_SESSION["permission"]="true";
    $sql="SELECT $chiave FROM $ruolo WHERE password='$password'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0){
		while($row = $result->fetch_assoc()) {
	    $_SESSION["id"]=$row["$chiave"];
		}}}
//sono inviato alla home della mia pagina
    $url = 'Elaborato_Home_Page.php';
	header( "Location: $url" );
    }else{
//altrimenti con errore appartente ad un nome utente/password sbagliato, vengo re-inviato alla pagina di accesso
    $_SESSION["errset"]= "true";
	$_SESSION["loginerr"] = "*Username o Password errati <br>";
    $url = 'Elaborato_Pagina_Di_Accesso.php';
	header( "Location: $url" );
    }}
?>