<?php
//connessione al database per le vaccinazioni
$servername = "localhost";
$username = "elaboratovacciniassurdi";
$password = "Gogeta12";
$dbname = "my_elaboratovacciniassurdi";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error){
  die("Connessione al database fallita: ".$conn->connect_error." ");
}	 
	$no_of_post = (isset($_GET['num'])?$_GET['num']:20);	
	$format = (isset($_GET['format'])?$_GET['format']:"xml");	
	$sql_query = "SELECT regione, COUNT(nome) as numero_vaccinati FROM paziente join sanitario on sanitario.id_sanitario=paziente.id_sanitario GROUP BY regione ORDER BY sanitario.id_sanitario LIMIT $no_of_post";
	$resultset = mysqli_query($conn, $sql_query) or die("database error:". mysqli_error($conn));	
	$Progresso_Vaccini = array();
	if(mysqli_num_rows($resultset)) {
		while($Pazienti_Vaccinati = mysqli_fetch_assoc($resultset)) {
			$Progresso_Vaccini[] = array('Pazienti_Vaccinati'=>$Pazienti_Vaccinati);
		}
	}
	/* output result in required format */
	if($format == 'json') {
		header('Content-type: application/json');
		echo json_encode(array('Progresso_Vaccini'=>$Progresso_Vaccini));
	} else if($format == 'xml') {
		header('Content-type: text/xml');
		echo '<Progresso_Vaccini>';
		foreach($Progresso_Vaccini as $index => $Pazienti_Vaccinati) {
			if(is_array($Pazienti_Vaccinati)) {
				foreach($Pazienti_Vaccinati as $key => $value) {
					echo '<',$key,'>';
					if(is_array($value)) {
						foreach($value as $tag => $val) {
							echo '<',$tag,'>',htmlentities($val),'</',$tag,'>';
						}
					}
					echo '</',$key,'>';
				}
			}
		}
		echo '</Progresso_Vaccini>';
	}	
	$conn->close();

?>