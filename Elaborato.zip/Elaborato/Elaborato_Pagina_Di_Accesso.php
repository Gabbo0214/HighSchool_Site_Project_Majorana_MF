<?php
//se una vecchia sessione è già inizializzata, la distruggo
if (isset($_SESSION)){
session_destroy();}
//inizio una sessione
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<!--Titolo della pagina-->
<title>Pagina di Accesso-Vaccinazione anti-covid</title>
<!--Codice css per la personalizzazione-->
<style>
.error {color: #FF0000;}
.h3 {
  font-family: "Optima", Optima, sans-serif;
  font-variant: small-caps;
}
#page-container {
  position: relative;
  right:10px;
  bottom:0;
  min-height: 100vh;
  width: 100%;
}

#content-wrap {
  position: relative;
  left: 10px;
  padding-bottom: 2.5rem;  
}

.button {
  border: none;
  color: white;
  padding: 12px 28px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}
.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #0000FF;
}

.button1:hover {
  background-color: #0000FF;
  color: white;
}
input[type=text] {
  width: 130px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
  background-position: 10px 10px; 
  background-repeat: no-repeat;
  padding: 12px 10px 12px 3px;
  transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
  width: 25%;
}
input[type=password] {
  width: 130px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
  padding: 12px 10px 12px 3px;
  transition: width 0.4s ease-in-out;
}

input[type=password]:focus {
  width: 25%;
}
.footer {
   position: absolute;
   left: 0;
   bottom: 0-10%;
   width: 102%;
   background-color: red;
   color: white;
   text-align: center;
}
</style>
</head>
<body>
<div id="page-container">
   <div id="content-wrap">
<?php
//inizializzo una variabile, oltre a diverse vairabili di sessione se non sono già inizializzate
$ruolo="";
if (!isset($_SESSION['errset'])) {
$_SESSION["loginerr"]="";
}
?>
<!--Inserisco il login ed il form per l'inserimento delle credenziali di accesso-->
<img src="primula.jpg" alt="Logo Pagina" width="300" height="120"><br><br>
<h2 class=h3>Hai bisogno di dati ed informazioni sull'andamento delle vaccinazioni?</h2>
<h3 class=h3>Scegli uno dei formati qui sotto per avere accesso ai nostri open data</h3>
<a href="https://elaboratovacciniassurdi.altervista.org/Elaborato/vaccinazione_opendata.php?&format=xml" class="button button1" target="_blank">Formato XML</a>	
<a href="https://elaboratovacciniassurdi.altervista.org/Elaborato/vaccinazione_opendata.php?&format=json" class="button button1" target="_blank">Formato JSON</a>
<a href="https://elaboratovacciniassurdi.altervista.org/Elaborato/Elaborato_PDF/creazione_conversione.php" class="button button1" target="_blank">Formato PDF</a>
<h3 class=h3>Oppure effettua una ricerca nella pagina apposita.</h3>
<form action="Elaborato_ricerca_dati.php" class="inline"><button class="button button1")>Search Page</button></form>
<a href="https://docs.google.com/spreadsheets/d/e/2PACX-1vSTl1IT8SBSIYl4gbSY7KUfbt0asgiwix-aw7ITpMAsferxhMR5PdNkDc57Iu7DuFPOD9zfxWIwb9FK/pubhtml?gid=804780466&single=true" class="button button1" target="_blank">Grafico Positivi</a>
<h2 class=h3>Se invece fai parte di personale autorizzato, <br> puoi ottenere ulteriori servizi effettuando il login.</h3>

<form method="post" action="Elaborato_Login.php">  
  <h3 class="h3">Effettua il login come:</h3>
   <p class="h3">-Capo Dipartimento:<input type="radio" name="ruolo" value="capo_dipartimento_regionale_user" required>
   -Membro di un Ente Locale:<input type="radio" name="ruolo" value="ente_locale_user" required>
   -Sanitario:<input type="radio" name="ruolo" value="sanitario_user" required></p>
   <span class="error"> <?php echo $_SESSION["loginerr"];?></span>
   <label for="Username" class="h3">Username:</label><br>
   <input type="text" name="username" value="" maxlength = "30" required><br>
   <br>
   <label for="password" class="h3">Password:</label><br>
   <input type="password" name="password" value="" maxlength = "30" required><br>
   <br>
   <input type="submit" value="Conferma Dati">
   </form>
   </div>
   <!--footer della pagina contenente informazioni.-->
   <div class="footer">
  <p>Copyright &#169; appartenente a "Gabriele Melucci s.r.l." 2020-2021<br>
  per maggiori informazioni, contattare su<br></p>
  <address>gabriele.melucci@gmail.com</address><br>
  <sup>nessuna nota legale al momento disponibile</sup>
</div>
</div>
</body>
</html>