<!--Inizializzo la sessione.-->
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<!--Titolo della pagina-->
<title>Search Page-Vaccinazione anti-covid</title>
<!--Codice css per la personalizzazione-->
<style>
.button {
  border: none;
  color: white;
  padding: 12px 28px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}
.button1 {
  position:fixed;
  top: 1%;
  right: 15px;
  background-color: white; 
  color: black; 
  border: 2px solid #FF0000;
}

.button1:hover {
  background-color: #FF0000;
  color: white;
}
.button2 {
  position:absolute;
  top:1%;
  right:150px;
  background-color: white; 
  color: black; 
  border: 2px solid #ADFF2F;
}

.button2:hover {
  background-color: #9ACD32;
  color: white;
}
.button3 {
  background-color: white; 
  color: black; 
  border: 2px solid #00FFFF;
}

.button3:hover {
  background-color: #00FFFF;
  color: white;
}
.h1 {
  font-family: "Optima", Optima, sans-serif;
  font-variant: small-caps;
}
.h3 {
  font-family: "Optima", Optima, sans-serif;
  font-variant: small-caps;
}
.p {
	position:fixed;
    top:200px;
	font-family: "Optima", Optima, sans-serif;
    font-variant: small-caps;
}
footer {
  position:fixed;
  bottom:0;
  left:0;
  height:150;
  width: 100%;
  text-align: center;
  padding: 3px;
  background-color: red;
  color: white;
}
</style>
</head>
<body>
<?php
//connessione al database sql
$servername = "localhost";
$username = "elaboratovacciniassurdi";
$password = "Gogeta12";
$dbname = "my_elaboratovacciniassurdi";
$conn = new mysqli($servername, $username, $password, $dbname);
//Passaggio tramite dei metodo post dei dati inseriti nel form per la ricerca
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$Regione=$_POST["regione"];
	$data1=$_POST["datap"];
	$data2=$_POST["dataf"];
	$Vaccino=$_POST["vaccino"];
//quey per l'ottenimento dei dati trovati
	$sql ="SELECT Data_Registrazione, nome, cognome, email  from paziente join piano_vaccinale on piano_vaccinale.codice_piano=paziente.codice_piano join sanitario on sanitario.ID_sanitario=paziente.ID_sanitario WHERE Data_Registrazione BETWEEN '$data1' and '$data2' AND sanitario.codice_ente='$Regione' AND nome_vaccino='$Vaccino'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0){
	 echo"<table border=1><tr><th>Data Vaccinazione</th><th>Nome</th><th>Cognome</th><th>Email</th>";
      while($row = $result->fetch_assoc()) {
      echo "<tr>";
      echo "<td> ".$row["Data_Registrazione"]."</td>"."<td>".$row["nome"]."</td>"."<td>".$row["cognome"]."</td>"."<td>".$row["email"]."</td>";
      echo "</tr>"; 
      }
    } else {
      echo "<p class='p'>Nessun risultato.</p>";
      }
}
$conn->close();
?>
<img src="primula.jpg" alt="Logo Pagina" width="300" height="120"><br><br>
<form action="Elaborato_Pagina_Di_Accesso.php" class="inline">
<button class="button button1")>Log Out</button>
</form>
<form action="Elaborato_Home_Page.php" class="inline">
<button class="button button2")>Indietro</button>
</form>
<h1 class="h1">Pagina Informazioni</h2>
<!--Form per i dati con cui effettuare la ricerca.-->
<?php if ($_SERVER["REQUEST_METHOD"] != "POST") {
?>
<h3 class="h3">Ricerca dati in tempo reale sulla vaccinazione anti-covid</h3>
 <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  <label for="regione">Seleziona una regione:</label>
  <select id="regione" name="regione">
    <option value="AQ">Abruzzo</option>
    <option value="PZ">Basilicata</option>
    <option value="CZ">Calabria</option>
    <option value="NA">Campania</option>
	<option value="BO">Emilia-Romagna</option>
    <option value="TS">Friuli Venezia Giulia</option>
    <option value="RO">Lazio</option>
    <option value="GE">Liguria</option>
	<option value="MI">Lombardia</option>
	<option value="AN">Marche</option>
    <option value="CB">Molise</option>
    <option value="TO">Piemonte</option>
    <option value="BA">Puglia</option>
	<option value="CA">Sardegna</option>
    <option value="PA">Sicilia</option>
    <option value="FI">Toscana</option>
    <option value="TN">Trentino-Alto Adige</option>
	<option value="PG">Umbria</option>
    <option value="AO">Valle d'Aosta</option>
    <option value="VE">Veneto</option>
  </select><br><br>
  <label for="datap">Seleziona una data di partenza:</label>
  <br><input type="date" name="datap" value="2019-01-01" min="2019-01-01" max="2022-12-31">
  <br><br>
  <label for="dataf">Seleziona una data di fine:</label>
  <br><input type="date" name="dataf" value="2022-12-31" min="2019-01-01" max="2022-12-31">
  <br><br>
  <label for="vaccino">Seleziona il vaccino utilizzato:</label>
  <select id="vaccino" name="vaccino">
    <option value="AstraZeneca">AstraZeneca</option>
    <option value="Pfizer">Pfizer</option>
    <option value="Moderna">Moderna</option>
	</select><br><br>
  <input type="submit" value="Conferma Dati">
  <input type="reset" value="Reimposta Dati">
 </form>
<?php
} 
if ($_SERVER["REQUEST_METHOD"] == "POST") {?>
 <!--Bottoni e logo della pagina.-->
     <form action="Elaborato_Ricerca_Pazienti.php" class="inline">
     <button class="button button3")>Cerca di nuovo</button>
     </form>
<?php	 
}
?>
<!--footer della pagina contenente informazioni.-->
<footer>
  <p>Copyright &#169; appartenente a "Gabriele Melucci s.r.l." 2020-2021<br>
  per maggiori informazioni, contattare su<br></p>
  <address>gabriele.melucci@gmail.com</address><br>
  <sup>nessuna nota legale al momento disponibile</sup>
</footer>
</body>
</html>