<!--Inizializzo la sessione.-->
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<!--Titolo della pagina-->
<title>Registrazione Pazienti-Vaccinazione anti-covid</title>
<!--Codice css per la personalizzazione del sito.-->
<style>
.error {color: #FF0000;}

.button {
  border: none;
  color: white;
  padding: 12px 28px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}
.button1 {
  position:fixed;
  top: 1%;
  right: 15px;
  background-color: white; 
  color: black; 
  border: 2px solid #FF0000;
}

.button1:hover {
  background-color: #FF0000;
  color: white;
}
.button2 {
  position:fixed;
  top:1%;
  right:150px;
  background-color: white; 
  color: black; 
  border: 2px solid #ADFF2F;
}

.button2:hover {
  background-color: #9ACD32;
  color: white;
}
.button3 {
  position:absolute;
  top:250px;
  left:10px;
  background-color: white; 
  color: black; 
  border: 2px solid #00FFFF;
}

.button3:hover {
  background-color: #00FFFF;
  color: white;
}
.berr{
	position:absolute;
	bottom:160px;
}
input[type=text] {
  width: 130px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
  background-position: 10px 10px; 
  background-repeat: no-repeat;
  padding: 12px 10px 12px 3px;
  transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
  width: 25%;
}
input[type=email] {
  width: 130px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
  background-position: 10px 10px; 
  background-repeat: no-repeat;
  padding: 12px 10px 12px 3px;
  transition: width 0.4s ease-in-out;
}

input[type=email]:focus {
  width: 25%;
}
.h2 {
	position:absolute;
	top:200px;
	font-family: "Optima", Optima, sans-serif;
    font-variant: small-caps;
}
#page-container {
  position: relative;
  right: 10px;
  min-height: 100vh;
}

#content-wrap {
  position: relative;
  left: 10px;
  padding-bottom: 2.5rem;    /* Footer height */
}
img {
 position:absolute;
 top:0px;
}
footer {
  position:absolute;
  bottom:0-10%;
  left:0;
  width: 102%;
  text-align: center;
  padding: 3px;
  background-color: red;
  color: white;
}
.f {
  position:fixed;
  bottom:0;
  left:0;
  width: 100%;
  text-align: center;
  padding: 3px;
  background-color: red;
  color: white;
}
</style>
</head>

<?php
//connessione al database per le vaccinazioni
$servername = "localhost";
$username = "elaboratovacciniassurdi";
$password = "Gogeta12";
$dbname = "my_elaboratovacciniassurdi";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error){
  die("Connessione al database fallita: ".$conn->connect_error." ");
}

//controllo di eventuali inserimenti nel form mancanti
if ($_SERVER["REQUEST_METHOD"] == "POST") {
//passaggio delle variabili del form tramite metodo post
    $checkmark="set";
	$Codice_Fiscale_Paziente=$_POST["CF"];
	$nome=$_POST["nome"];
	$cognome=$_POST["cognome"];
	$Data_Di_Nascita=$_POST["BD"];
	$Residenza=$_POST["Residenza"];
	$email=$_POST["email"];
	$Valore1=$_POST["valorecod"];
	$Valore2=$_POST["valuecod"];
	$nome_vaccino=$_POST["vaccino"];
	$adesso_giorno=date("Y-m-d");
	$id_sanitario=$_SESSION['id'];
	
//query per ottenere quella che sarà la chiave esterna (dal piano vaccinale) per il paziente

	$sql="SELECT piano_vaccinale.Codice_Piano FROM piano_vaccinale join sanitario on sanitario.codice_piano=piano_vaccinale.codice_piano WHERE id_sanitario='$id_sanitario'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0){
		while($row = $result->fetch_assoc()) {
	    $_SESSION["codice_piano"]=$row["Codice_Piano"];
	}}
	$codice_piano=$_SESSION["codice_piano"];
//Calcolo del codice di gravità/rischio sulla base di alcuni fattori in un sistema a punti

    $eta = floor((time() - strtotime($Data_Di_Nascita)) / 31556926);
	if($eta>=80){
	$Valore3=3;	
	}
	else{
		if($eta>=70){
		$Valore3=2;
		}else{
		   if($eta>=60){
		   $Valore3=1;
		   }
		   else{
		   $Valore3=0;
		   }
		}
	}
	$urgenza=$Valore1+$Valore2+$Valore3;
	if($urgenza>=3){
		$Codice_fragilita="MOLTO_ALTA";
	}
	else{
		if($urgenza=2){
			$Codice_fragilita="ALTA";
		}else{
			if($urgenza=2){
		 $Codice_fragilita="MEDIA";
			}else{
			$Codice_fragilita="BASSA";
			}
		}
	}
//svuoto eventuali errori 
    $nomerr="";
    $cognomerr="";
    $residerr=""; 
    $valorerr="";
    $valuerr="";
//Query per l'inserimento del paziente
	$sql = "INSERT INTO paziente (Codice_Fiscale_Paziente, nome, cognome, Data_Di_Nascita, Residenza, email, Codice_Fragilita, nome_vaccino, Data_Registrazione, id_sanitario, codice_piano) VALUES ('$Codice_Fiscale_Paziente', '$nome' ,'$cognome', '$Data_Di_Nascita' , '$Residenza', '$email', '$Codice_fragilita', '$nome_vaccino', '$adesso_giorno', '$id_sanitario', '$codice_piano')";
if ($conn->query($sql) === TRUE){
  echo "<h2 class='h2'>Nuovo Paziente inserito con successo.</h2> <br><br>";
  $sql="UPDATE piano_vaccinale SET Numero_Persone_Vaccinate = Numero_Persone_Vaccinate + 1 WHERE codice_piano='$codice_piano' ";
        if ($conn->query($sql) === TRUE){	
		}else{
			echo "<p class='berr'><b>*Errore durante l'operazione:</b> " . $sql ."<br>". $conn->error."</p>";}
} else {
  echo "<p class='berr'><b>*Errore durante l'operazione:</b> " . $sql ."<br>". $conn->error."</p>";}
 ?>
<div class="f">
<!--Il footer contenente informazioni sulla pagina.-->
  <p>Copyright &#169; appartenente a "Gabriele Melucci s.r.l." 2020-2021<br>
  per maggiori informazioni, contattare su<br></p>
  <address>gabriele.melucci@gmail.com</address><br>
  <sup>nessuna nota legale al momento disponibile</sup>
</div>
<?php
}
$conn->close();
?>
<body>
<div id='page-container'>
<div id='content-wrap'>
<img src="primula.jpg" alt="Logo Pagina" width="300" height="120"><br><br>
<form action="Elaborato_Pagina_Di_Accesso.php" class="inline">
<button class="button button1")>Log Out</button>
</form>
<form action="Elaborato_Home_Page.php" class="inline">
<button class="button button2")>Indietro</button>
</form>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") { ?>
<form action="Elaborato_Registrazione_Pazienti.php" class="inline">
<button class="button button3")>Inserisci un nuovo paziente</button>
</form>
<?php
}
?>
<?php if ($_SERVER["REQUEST_METHOD"] != "POST") {
?>
<!--Il form per l'inserimento dei dati dei pazienti.-->
 <br><br><br><br><br>
 <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Codice Fiscale: <br><input type="text" name="CF" value="" minlength = "16" maxlength = "16" required><br><br>
  Nome: <br><input type="text" name="nome" value="" maxlength = "30" required><br><br>
  Cognome: <br><input type="text" name="cognome" value="" maxlength = "30" required><br><br>
  Data di nascita: <br><input type="date" name="BD" value="" min="1900-01-01" max="2022-12-31" required><br><br> 
  Indirizzo: <br><input type="text" name="Residenza" maxlength = "40" value="" required><br><br>
  E-mail: <br><input type="email" name="email" value="" maxlength = "50" required><br><br><br>
  <label for="vaccino">Seleziona il vaccino utilizzato:</label>
  <select id="vaccino" name="vaccino">
    <option value="AstraZeneca">AstraZeneca</option>
    <option value="Pfizer">Pfizer</option>
    <option value="Moderna">Moderna</option>
	</select><br><br>
  Il paziente e' affetto da patologie croniche/rare?<br>
  Si <input type="radio" name="valorecod" value="3"required><br>
  No<input type="radio" name="valorecod" value="0"required><br><br>
  Il paziente e' in possesso di disabilita'?<br>
  Si <input type="radio" name="valuecod" value="1"required><br>
  No<input type="radio" name="valuecod" value="0"required><br><br>
  <input type="submit" value="Conferma Dati">
  <input type="reset" value="Reimposta Dati">
 </form>
</div>
<footer>
<!--Il footer contenente informazioni sulla pagina.-->
  <p>Copyright &#169; appartenente a "Gabriele Melucci s.r.l." 2020-2021<br>
  per maggiori informazioni, contattare su<br></p>
  <address>gabriele.melucci@gmail.com</address><br>
  <sup>nessuna nota legale al momento disponibile</sup>
</footer>
<?php
} 
?>
</div>
 </body>
</html>