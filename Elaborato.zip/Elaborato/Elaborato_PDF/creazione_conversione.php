<?php
//connessione al database
$servername = "localhost";
$username = "elaboratovacciniassurdi";
$password = "Gogeta12";
$dbname = "my_elaboratovacciniassurdi";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error){
  die("Connessione al database fallita: ".$conn->connect_error." ");
}	 
	
//creazione file csv
   $result = mysqli_query($conn,"SELECT regione, COUNT(nome) as numero_vaccinati FROM paziente join sanitario on sanitario.id_sanitario=paziente.id_sanitario GROUP BY regione ORDER BY sanitario.id_sanitario");
   if (!$result) die('Couldn\'t fetch records');
   $num_fields = mysqli_num_fields($result);
   $headers = array();
   for ($i = 0; $i < $num_fields; $i++) {
    $headers[] = mysqli_field_name($result , $i);
   }
   $fp = fopen('Opendata.csv', 'w');
    fputcsv($fp, $headers);
    while ($row = $result->fetch_array(MYSQLI_NUM)) {
        fputcsv($fp, array_values($row));
    }
   fclose($fp);
   $url = 'opendatapdf.php';
   header( "Location: $url" );
    
	
	
	function mysqli_field_name($result, $field_offset)
{
    $properties = mysqli_fetch_field_direct($result, $field_offset);
    return is_object($properties) ? $properties->name : null;
}
?>